import { checkSum } from "../utils";
import { Config } from "./../types";

const config: Config = {
  WALLETS: [
    {
      PRIVATE_KEY: "0xf83F4c3A25b8FEE1722d76e5F72AaFcA00845011",
      ADDRESS:
        "0x2c283ea64fe7352dd1b1125723a260524e9ad0a6c0a8008b240f904265c0cfd2",
    },
    {
      PRIVATE_KEY: "0xf83F4c3A25b8FEE1722d76e5F72AaFcA00845011",
      ADDRESS:
        "0x2c283ea64fe7352dd1b1125723a260524e9ad0a6c0a8008b240f904265c0cfd2",
    },
  ],
  PRICEIMPACT: [{ SELLING: 0.3, BUYING: 1 }],
  EXECUTION_TIME: [3, 1, 5, 6],
  BLOXROUTE: {
    ENDPOINT: "wss://bsc.feed.blxrbdn.com:28333",
  },
  BSC: {
    NODE_URL: "https://bsc-dataseed1.binance.org/",
    WBNB_ADDRESS: "0xbb4CdB9CBd36B01bD1cBaEBF2De08d9173bc095c",
    PANCAKE_V2_ROUTE: "0x10ed43c718714eb63d5aa57b78b54704e256024e",
  },
  TOKENS_TO_MONITOR: [
    "0x2b3f34e9d4b127797ce6244ea341a83733ddd6e4",
    "0xe4fae3faa8300810c835970b9187c268f55d998f", //CATE
  ],
  EXECUATION_AMOUNT: [0.5, 0.3, 1, 1.0],
  DB: {
    MONGO_URL: "mongodb://localhost:27017/market-making-dev",
  },
};

export { config };
